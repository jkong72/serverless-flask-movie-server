# movie_recomand

## 관련 외부 링크
관련 GitBook   
https://while-true-learn-api.gitbook.io/app-restful-api-1/api-reference/api/api

관련 Google Colab   
https://colab.research.google.com/drive/1vX1_W8v6tfBwnW-2VH8RPUxhKFDIAbh5?usp=sharing

---
