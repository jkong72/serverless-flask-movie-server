import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jkong',
    application_name='serverless-flask-movie-server',
    app_uid='gzwMMGbzN7GL2Z9HbT',
    org_uid='c566ecc3-426e-4826-9850-f0c342e81dc2',
    deployment_uid='d4cbac9f-b6ac-482e-9784-429871e3c585',
    service_name='serverless-flask-movie-server',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-flask-movie-server-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
