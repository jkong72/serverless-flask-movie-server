class Config :
    SECRET_KEY = 't51a2n3ag4y8445i43ou1nn5769w5694y2s34t2r' # 노출되어선 안되는 임의의 보안 키